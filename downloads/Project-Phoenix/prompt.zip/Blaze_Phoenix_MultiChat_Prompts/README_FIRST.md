# Blaze Systems Project Phoenix — Multi-chat prompts

**Contents:** exactly **7 full-team `.txt` prompts** in `FULL_7_PROMPTS/`, exactly **4 lightweight-team `.txt` prompts** in `LIGHT_4_PROMPTS/`. Use **ONE** team layout at a time, not both. Additional files are optional help/template files (not extra chat assignments).

## How to start

1. Create a ChatGPT Project called **Blaze Systems — Project Phoenix** (a regular, non-temporary chat environment with GitHub access), or open separate ordinary chat tabs with connected GitHub.
2. **Full setup:** paste `FULL_7_PROMPTS/00_MASTER_PROJECT_PHOENIX.txt` into the Master chat first; then paste each of the other 6 prompts in its own chat. **Light setup:** paste `LIGHT_4_PROMPTS/00_LIGHT_MASTER_AUDIT_COORDINATION.txt` first, followed by the other 3 prompts.
3. Give each chat access to the SAME repository and control-plane issue. Make sure each uses a DIFFERENT role/branch and does not overwrite another chat's work.
4. Master creates/discovers `[PHX] CONTROL PLANE`; every chat reads it whenever starting/resuming and before shared interface changes. Master owns global direction, QA gates, and integration sequencing.
5. Have each chat verify what tools exist and start useful **real work immediately**. If GitHub write/build permissions are missing, it must report the real limitation rather than invent success.

## Hourly continuation: what works and what does not

A prompt by itself **cannot automatically wake or message a dormant ChatGPT tab**. This ZIP assigns every role a 60-minute **resume contract**, but autonomous execution requires a genuinely available **recurring task** or an external authorized AI worker orchestrator that launches that role, reloads GitHub state, runs code/tests, and posts checkpoints. Ordinary chat tabs are NOT durable background agents. Do not confuse regular check-in messages with running AI development.

`OPTIONAL_HOURLY_SIGNAL/phoenix-hourly-signal.yml` is a **signal-only** GitHub Actions example: copy it to `.github/workflows/phoenix-hourly-signal.yml` in the repository to get a heartbeat in an issue. It **does not wake ChatGPT tabs or do development**. It runs every hour when GitHub's scheduler runs (potential delays/disablement possible) and may write up to 24 issue comments per day. Use only if that visibility/noise is desirable. It uses no Codex and no external AI credentials.

To get **actual autonomous hourly continuation**, connect a separate approved worker runtime/orchestrator with authenticated GitHub access, model API/CLI access **that is not Codex**, secure secret storage, isolated branches, a per-role lock, observability, permission scoping, budget limits, and a scheduler (`7 * * * *` UTC or another per-hour cadence). That runtime must load the role prompt fresh each activation and implement the resume steps. No such runtime is installed or activated by merely extracting this ZIP.

## Authority and safety

- **Absolutely no Codex** (app, CLI, API, agent, workflow).
- No production payment migration, real router flashing, signer provisioning, customer deployment or unsafe hardware operations without authorized gates and actual evidence.
- Each role distinguishes **NOT TESTED / SIMULATED / CI VERIFIED / HARDWARE ACCEPTED / PRODUCTION READY**. Preview != production.
- GitHub Actions, ordinary connected GitHub tools, and non-Codex development tools are allowed.

## Communication documentation

See `COMMUNICATION_PROTOCOL.md` for the BLAZE-COMMS/1 message format and ownership boundaries. The text prompts are self-contained, so only copy one `.txt` prompt per chat.
