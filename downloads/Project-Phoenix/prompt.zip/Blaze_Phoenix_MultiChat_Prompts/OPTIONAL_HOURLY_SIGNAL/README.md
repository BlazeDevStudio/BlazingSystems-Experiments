# Optional GitHub hourly signal, not an AI worker

Copy `phoenix-hourly-signal.yml` into `.github/workflows/phoenix-hourly-signal.yml` in the repository's default branch. It will create/find a **single** `[PHX] HOURLY SIGNAL` GitHub issue and add one UTC-stamped comment per scheduled run, listing the expected roles. The workflow does **not** trigger ChatGPT tabs, execute code changes, run prompts, or interact with an AI API.

Set a repository variable `PHX_TEAM_MODE` to `LIGHT` to list the four light-team roles; the default is `FULL`. Use Actions > Phoenix Hourly Signal > Run workflow for a manual smoke test. GitHub scheduling is not guaranteed to run exactly on the minute. The workflow has `issues: write`, and the user/repo admin must authorize it. Limit or remove the workflow once an external actual-worker orchestrator is configured to avoid duplicate and noisy status notifications.

No Codex is used. If you need continuous unattended AI development, this signal must be replaced/extended by a real worker runtime that can invoke an AI model, access GitHub, handle tools, and commit verified work, with scope, secrets, locks, and budgets.
