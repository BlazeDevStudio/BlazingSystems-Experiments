# BLAZE-COMMS/1 — Project Phoenix coordination specification

**Transport:** a SINGLE GitHub issue named `[PHX] CONTROL PLANE` + role-owned task issues, PRs, GitHub Actions runs, and handover files. Chats do **not** directly message each other.

**Authority:** MASTER is the only global dispatcher, assignment owner, and release gate. Worker engineers post progress, proposals, blockers, and independent test evidence. Workers do not merge others' PRs. If project grants otherwise, do not use expanded privileges absent an explicit task.

**Event envelope:** include a fenced JSON block in issue comments, with keys `protocol`, `message_id`, `from`, `to`, `type`, `priority`, `task_id`, `branch`, `base_sha`, `scope`, `status`, `evidence`, `blockers`, `next_action`, `updated_utc`.

**Types:** ASSIGN, ACK, PROGRESS, BLOCKER, REQUEST_REVIEW, DONE, DECISION. **Statuses:** QUEUED, IN_PROGRESS, BLOCKED, PR_READY, VERIFIED, MERGED. Physical test states must not be reduced to a boolean; preserve LAB vs HARDWARE and evidence links.

**Chat execution protocol:**

1. On any activation, read master issue/PRs, task details, current remote branch SHA, prior resume checkpoint, CI, and upstream API changes.
2. If task already merged/superseded, do NOT reimplement. Acknowledge and choose next assigned task.
3. Claim one task per worker, use role-specific branch/PR, and record exact affected paths. Warn Master before modifying shared API/schema.
4. Do reversible engineering and focused tests; commit only real changes; attach real job logs/SHAs.
5. Post short end-of-run checkpoint: current task, actual work, exact test result, risk, next step.
6. Before merge, Master resolves ownership collisions and asks QA for critical money, crypto and migration PRs. Independently verify the same SHA.

**Sync:** event-driven before shared changes/merges, at start/end of each worker activation, and at least hourly during true ongoing execution. A scheduled issue comment is only a signal. ChatGPT conversations cannot be programmatically awakened by these files alone.

**Recovery:** one active run per role and scheduled hour. Use idempotent issue/comments; on crash or delayed trigger, resume from GitHub checkpoint and do NOT duplicate effects. Don't claim success without evidence.

**Full team:** PHX-MASTER, PHX-CORE, PHX-RENTAL, PHX-PISONET, PHX-HARDWARE, PHX-QA, PHX-RELEASE.

**Light team:** PHX-L-MASTER, PHX-L-CORE, PHX-L-APPS, PHX-L-VERIFY.
